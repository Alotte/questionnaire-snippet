1. Open a terminal or command prompt.

2. Navigate to the project folder.

3. Run the following command to install the project dependencies:


npm install

This will ensure that all required dependencies are installed.

Once the installation is complete, you can start the application by running the command:


npm run dev

This command will launch the development server and compile the project.