export interface QuestionnaireListing {
    title: string;
    creationDate: string;
    author: string;
    status: string;
  }